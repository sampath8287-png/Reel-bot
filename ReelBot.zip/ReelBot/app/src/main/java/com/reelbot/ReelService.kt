package com.reelbot

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class ReelService : AccessibilityService() {
    private lateinit var prefs: SharedPreferences
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var last = 0L
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }
    private val alwaysCount = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.snapchat.android")
    private val keys = listOf("reel", "clips", "short")

    override fun onServiceConnected() {
        prefs = getSharedPreferences("reelbot", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    private fun refresh() {
        if (prefs.getBoolean("running", false)) {
            showBubble(); bubble?.text = "🤖 ${prefs.getInt("count", 0)}"
        } else hideBubble()
    }

    private fun showBubble() {
        if (bubble != null) return
        val tv = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(40, 16, 40, 16)
            background = GradientDrawable().apply {
                cornerRadius = 100f; setColor(0xDD6C3CE0.toInt()); setStroke(4, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 90 }
        wm.addView(tv, lp); bubble = tv
    }

    private fun hideBubble() { bubble?.let { runCatching { wm.removeView(it) } }; bubble = null }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!prefs.getBoolean("running", false)) return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        val pkg = e.packageName?.toString() ?: return
        val now = SystemClock.uptimeMillis()
        if (now - last < 700) return
        if (pkg !in alwaysCount && !inReels(rootInActiveWindow, 0)) return
        last = now
        prefs.edit().putInt("count", prefs.getInt("count", 0) + 1).apply()
    }

    private fun inReels(n: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (n == null || depth > 12) return false
        val id = n.viewIdResourceName?.lowercase()
        if (id != null && keys.any { id.contains(it) }) return true
        for (i in 0 until n.childCount) if (inReels(n.getChild(i), depth + 1)) return true
        return false
    }

    override fun onInterrupt() {}
    override fun onDestroy() { hideBubble(); super.onDestroy() }
}

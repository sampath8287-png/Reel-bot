package com.reelbot

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var count: TextView
    private lateinit var toggle: Button
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> render() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("reelbot", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(60, 60, 60, 60)
            setBackgroundColor(Color.parseColor("#F3EEFF"))
        }
        root.addView(TextView(this).apply { text = "🤖"; textSize = 90f; gravity = Gravity.CENTER })
        count = TextView(this).apply { textSize = 56f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#6C3CE0")) }
        root.addView(count)
        root.addView(TextView(this).apply { text = "reels watched"; textSize = 16f; gravity = Gravity.CENTER })
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle)
        root.addView(Button(this).apply { text = "Reset"; setOnClickListener { prefs.edit().putInt("count", 0).apply() } })
        setContentView(root)
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun onToggle() {
        if (!serviceEnabled()) {
            Toast.makeText(this, "Turn on 'Reel Bot' in Accessibility, then come back", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        prefs.edit().putBoolean("running", !prefs.getBoolean("running", false)).apply()
    }

    private fun render() {
        count.text = prefs.getInt("count", 0).toString()
        toggle.text = if (prefs.getBoolean("running", false)) "⏹ Stop" else "▶ Start"
    }

    override fun onResume() { super.onResume(); prefs.registerOnSharedPreferenceChangeListener(listener); render() }
    override fun onPause() { super.onPause(); prefs.unregisterOnSharedPreferenceChangeListener(listener) }
}
